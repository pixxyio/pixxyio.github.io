import React from 'react'

import { Helmet } from 'react-helmet'

import './frame11.css'

const Frame11 = (props) => {
  return (
    <div className="frame11-container">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="frame11-frame1">
        <div className="frame11-group8">
          <span className="frame11-text">
            <span>
              <span>
                Во избежании потери средств путем мошенничества, обратите
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>
                внимание на адрес сайта и логин бота. Они должны совпадать.
              </span>
            </span>
          </span>
          <span className="frame11-text05">!</span>
          <div className="frame11-r">
            <img
              alt="Vector586"
              src="/external/vector586-0lbf.svg"
              className="frame11-vector"
            />
            <img
              alt="Vector587"
              src="/external/vector587-a7t.svg"
              className="frame11-vector01"
            />
            <img
              alt="Vector588"
              src="/external/vector588-dofv.svg"
              className="frame11-vector02"
            />
            <img
              alt="Vector589"
              src="/external/vector589-l3iq.svg"
              className="frame11-vector03"
            />
            <img
              alt="Vector5810"
              src="/external/vector5810-rz5o.svg"
              className="frame11-vector04"
            />
            <img
              alt="Vector5811"
              src="/external/vector5811-vj4k.svg"
              className="frame11-vector05"
            />
            <img
              alt="Vector5812"
              src="/external/vector5812-a6g.svg"
              className="frame11-vector06"
            />
            <img
              alt="Vector5813"
              src="/external/vector5813-3fx.svg"
              className="frame11-vector07"
            />
            <img
              alt="Vector5814"
              src="/external/vector5814-z25n.svg"
              className="frame11-vector08"
            />
            <img
              alt="Vector5815"
              src="/external/vector5815-p4zq.svg"
              className="frame11-vector09"
            />
            <img
              alt="Vector5816"
              src="/external/vector5816-a3uj.svg"
              className="frame11-vector10"
            />
            <img
              alt="Vector5817"
              src="/external/vector5817-pja4.svg"
              className="frame11-vector11"
            />
            <img
              alt="Vector5818"
              src="/external/vector5818-ktlt.svg"
              className="frame11-vector12"
            />
          </div>
          <img
            alt="Vector44470"
            src="/external/vector44470-it5r.svg"
            className="frame11-vector4"
          />
          <span className="frame11-text06">
            <span>Поменять в боте</span>
          </span>
          <span className="frame11-text08">
            <span className="frame11-text09">tg:</span>
            <span className="frame11-text10">
              {' '}
              @qckex
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <span className="frame11-text11">link:</span>
            <span> qckex.com</span>
          </span>
          <img
            alt="Rectangle54475"
            src="/external/rectangle54475-gtck-900w.png"
            className="frame11-rectangle5"
          />
          <img
            alt="Rectangle44471"
            src="/external/rectangle44471-6a6-200h.png"
            loading="eager"
            className="frame11-rectangle4 button"
          />
          <img
            alt="image"
            src="/external/%C3%B0%C2%9C%C3%B0%C2%B5%C3%B0%C2%BD%C3%B1%C2%8F%C3%B0%C2%B9%20%C3%B0%C2%BB%C3%B1%C2%8E%C3%B0%C2%B1%C3%B1%C2%83%C3%B1%C2%8E%20%C3%B0%C2%BA%C3%B1%C2%80%C3%B0%C2%B8%C3%B0%C2%BF%C3%B1%C2%82%C3%B0%C2%BE%C3%B0%C2%B2%C3%B0%C2%B0%C3%B0%C2%BB%C3%B1%C2%8E%C3%B1%C2%82%C3%B1%C2%83%20%C3%B0%C2%BD%C3%B0%C2%B0%20%C3%B0%C2%BA%C3%B0%C2%B0%C3%B1%C2%80%C3%B1%C2%82%C3%B1%C2%83%2C%20%C3%B0%C2%BF%C3%B0%C2%BE%C3%B0%C2%BB%C3%B1%C2%83%C3%B1%C2%87%C3%B0%C2%B0%C3%B0%C2%B9%20%C3%B0%C2%BD%C3%B0%C2%B0%C3%B0%C2%BB%C3%B0%C2%B8%C3%B1%C2%87%C3%B0%C2%BD%C3%B1%C2%8B%C3%B0%C2%B5%20%C3%B0%C2%BA%C3%B1%C2%83%C3%B1%C2%80%C3%B1%C2%8C%C3%B0%C2%B5%C3%B1%C2%80%C3%B0%C2%BE%C3%B0%C2%BC%20%C3%B0%C2%B2%20%C3%B1%C2%81%C3%B1%C2%82%C3%B1%C2%80%C3%B0%C2%B0%C3%B0%C2%BD%C3%B0%C2%B0%C3%B1%C2%85%20%C3%B0%C2%90%C3%B0%C2%B7%C3%B0%C2%B8%C3%B0%C2%B8%20%C3%B0%C2%B8%C3%B0%C2%BB%C3%B0%C2%B8%20%C3%B0%C2%BF%C3%B0%C2%BE%20%C3%B0%C2%BF%C3%B0%C2%B8%C3%B0%C2%BD-%C3%B0%C2%BA%C3%B0%C2%BE%C3%B0%C2%B4%C3%B1%C2%83%20%C3%B0%C2%B2%20%C3%B0%C2%B1%C3%B0%C2%B0%C3%B0%C2%BD%C3%B0%C2%BA%C3%B0%C2%BE%C3%B0%C2%BC%C3%B0%C2%B0%C3%B1%C2%82%C3%B0%C2%B5..svg"
            loading="lazy"
            className="frame11-image"
          />
        </div>
        <div className="frame11-container1">
          <span className="frame11-text13">₽</span>
          <img
            alt="SVG6039"
            src="/external/svg6039-kvpp.svg"
            className="frame11-svg"
          />
          <img
            alt="Vector46040"
            src="/external/vector46040-vadf.svg"
            className="frame11-vector41"
          />
        </div>
      </div>
    </div>
  )
}

export default Frame11
