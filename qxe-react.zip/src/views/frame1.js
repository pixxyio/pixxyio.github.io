import React from 'react'

import { Helmet } from 'react-helmet'

import './frame1.css'

const Frame1 = (props) => {
  return (
    <div className="frame1-container">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <img
        alt="image"
        src="/external/svg6039-kvpp.svg"
        className="frame1-image"
      />
      <div className="frame1-frame1">
        <div className="frame1-group8">
          <span className="frame1-text">
            <span>
              <span>
                Во избежании потери средств путем мошенничества, обратите
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>
                внимание на адрес сайта и логин бота. Они должны совпадать.
              </span>
            </span>
          </span>
          <span className="frame1-text05">!</span>
          <div className="frame1-r">
            <img
              alt="Vector586"
              src="/external/vector586-s01.svg"
              className="frame1-vector"
            />
            <img
              alt="Vector587"
              src="/external/vector587-3k6m.svg"
              className="frame1-vector01"
            />
            <img
              alt="Vector588"
              src="/external/vector588-ztu7.svg"
              className="frame1-vector02"
            />
            <img
              alt="Vector589"
              src="/external/vector589-3pt.svg"
              className="frame1-vector03"
            />
            <img
              alt="Vector5810"
              src="/external/vector5810-996g.svg"
              className="frame1-vector04"
            />
            <img
              alt="Vector5811"
              src="/external/vector5811-smqr.svg"
              className="frame1-vector05"
            />
            <img
              alt="Vector5812"
              src="/external/vector5812-50ld.svg"
              className="frame1-vector06"
            />
            <img
              alt="Vector5813"
              src="/external/vector5813-5rf6i.svg"
              className="frame1-vector07"
            />
            <img
              alt="Vector5814"
              src="/external/vector5814-hwrc.svg"
              className="frame1-vector08"
            />
            <img
              alt="Vector5815"
              src="/external/vector5815-asp.svg"
              className="frame1-vector09"
            />
            <img
              alt="Vector5816"
              src="/external/vector5816-hazq.svg"
              className="frame1-vector10"
            />
            <img
              alt="Vector5817"
              src="/external/vector5817-517l.svg"
              className="frame1-vector11"
            />
            <img
              alt="Vector5818"
              src="/external/vector5818-dgsm.svg"
              className="frame1-vector12"
            />
          </div>
          <img
            alt="Rectangle44471"
            src="/external/rectangle44471-t517-200h.png"
            className="frame1-rectangle4"
          />
          <img
            alt="Vector44470"
            src="/external/vector44470-gq9.svg"
            className="frame1-vector4"
          />
          <span className="frame1-text06">
            <span>Поменять в боте</span>
          </span>
          <span className="frame1-text08">
            <span className="frame1-text09">tg:</span>
            <span className="frame1-text10">
              {' '}
              @qckex
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <span className="frame1-text11">link:</span>
            <span> qckex.com</span>
          </span>
          <img
            alt="Rectangle54475"
            src="/external/rectangle54475-abll-900w.png"
            className="frame1-rectangle5"
          />
        </div>
      </div>
    </div>
  )
}

export default Frame1
